# 文档索引

- [数据库和数据格式-概要](正式文档/databaseAndStructure-summary.md)
- [数据库和数据格式-通用系统](正式文档/databaseAndStructure-general.md)
- [数据库和数据格式-账户系统](正式文档/databaseAndStructure-account.md)
- [数据库和数据格式-用户系统](正式文档/databaseAndStructure-user.md)
- [数据库和数据格式-作品系统](正式文档/databaseAndStructure-work.md)
- [数据库和数据格式-活动系统](正式文档/databaseAndStructure-activity.md)
- [数据库和数据格式-消息系统](正式文档/databaseAndStructure-message.md)
- [特性列表](正式文档/izuoba平台特性列表.xlsx)
