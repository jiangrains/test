## 概要

### 数据结构的包装

    {
        sysCode: 1, // 定义系统码
        bizCode: 10110100001, // 定义业务码
        data: {...}, // 返回的数据
        sysDate: 123214343248, //返回UTC时间，Long
        errorMsg: [String]
    }

### 接口签名

### 系统码

|代码|描述
|---|---
|-1|系统未知错误
|0|调用失败
|1|调用成功
|2|令牌失效或已过期

### 业务码

|第一段系统代码（100开始，8进制）|第二段为子系统（100开始，8进制）
|---|---
|100|100

### ERROR CODE


	//-----------------//
	// 全局错误码定义//
	//-----------------//

	/** token 非法. */
	public final static String TOKEN_ILLEGAL = "TOKEN_ILLEGAL";
	
	/** 验证码错误. */
	public final static String CAPTCHA_ILLEGAL = "CAPTCHA_ILLEGAL";
	
	/** 写云存储失败 */
	public static final String WIRTE_YUN_FAIL = "WIRTE_YUN_FAIL";
	
	/** 格式错误. */
	public final static String FORMAT_ILLEGAL = "FORMAT_ILLEGAL";
	
	/** 消息发送错误，不再作细分. */
	public static final String NOTIFY_MESSAGE_ERROR = "NOTIFY_MESSAGE_ERROR";
	
	//-----------------//
	// 账户系统错误码定义//
	//-----------------//
	
	/** 账户类型不正确  */
	public static final String ACCOUNT_TYPE_ERROR = "ACCOUNT_TYPE_ERROR";
	
	/** 账户错误. */
	public final static String ACCOUNT_INVALID = "ACCOUNT_INVALID";
	
	/** 账户锁定. */
	public final static String ACCOUNT_LOCKED = "ACCOUNT_LOCKED";

	/** 账户末激活. */
	public final static String ACCOUNT_NOTACTIVATED = "ACCOUNT_NOTACTIVATED";
	
	/** 账户不存在. */
	public static final String ACCOUNT_NOT_EXISTS = "ACCOUNT_NOT_EXISTS";
	
	/** 激活码已过期. */
	public static final String ACTIVE_CODE_EXPIRED = "ACTIVE_CODE_EXPIRED";

	/** 邮件格式错误. */
	public final static String EMAIL_FORMAT_ILLEGAL = "EMAIL_FORMAT_ILLEGAL";

	/** 邮箱号重复. */
	public final static String EMAIL_REPEAT = "EMAIL_REPEAT";

	/** 手机号格式错误. */
	public final static String PHONE_FORMAT_ILLEGAL = "PHONE_FORMAT_ILLEGAL";

	/** 手机号重复. */
	public final static String PHONE_REPEAT = "PHONE_REPEAT";

	/** 密码格式错误. */
	public final static String PASSWORD_FORMAT_ILLEGAL = "PASSWORD_FORMAT_ILLEGAL";
	
	/** 密码不正确. */
	public static final String PASSWORD_INVALID = "PASSWORD_INVALID";

	/** 用户名或者密码错误. */
	public final static String USERNAME_OR_PASSWORD_INVALID = "USERNAME_OR_PASSWORD_INVALID";

	

	//-----------------//
	// 用户系统错误码定义//
	//-----------------//
	
	/** 用户无效. */
	public static final String USER_INVALID = "USER_INVALID";
	
	/** 不能关注自己的作品. */
	public static final String CANNOT_FOLLOW_SELF_WORK = "CANNOT_FOLLOW_SELF_WORK";
	
	/** 不能关注自己的活动. */
	public static final String CANNOT_FOLLOW_SELF_ACTIVITY = "CANNOT_FOLLOW_SELF_ACTIVITY";
	
	/** 不能关注自己. */
	public static final String CANNOT_FOLLOW_SELF = "CANNOT_FOLLOW_SELF";

	
	//-----------------//
	// 作品系统错误码定义//
	//-----------------//
	
	/** 作品无效. */
	public final static String WORK_INVALID = "WORK_INVALID";
	
	/** 作品不存在. */
	public static final String WORK_NOT_EXISTS = "WORK_NOT_EXISTS";
	
	/** 非本人作品 */
	public static final String NOT_WORK_OWNER = "NOT_WORK_OWNER";
	
	/** 作品分类不存在 */
	public static final String WORK_CATEGORY_NOT_EXISTS = "WORK_CATEGORY_NOT_EXISTS";
	
	/** 作品是私有的 */
	public static final String WORK_IS_PRIVATE = "WORK_IS_PRIVATE";
	
	/** 作品正在参赛 */
	public static final String WORK_IS_ENROLL = "WORK_IS_ENROLL";

	
	//-----------------//
	// 活动系统错误码定义//
	//-----------------//
	
	/** 活动无效. */
	public static final String ACTIVITY_INVALID = "ACTIVITY_INVALID";
	
	/** 活动不存在. */
	public static final String ACTIVITY_NOT_EXISTS = "ACTIVITY_NOT_EXISTS";
	
	/** 非本人活动 */
	public static final String NOT_ACTIVITY_OWNER = "NOT_ACTIVITY_OWNER";

	/**  活动信息模板不存在 */
	public static final String INFO_TPL_NOT_EXISTS = "INFO_TPL_NOT_EXISTS";
	
	/**  提交作品信息模板不存在 */
	public static final String SUBMIT_TPL_NOT_EXISTS = "SUBMIT_TPL_NOT_EXISTS";

