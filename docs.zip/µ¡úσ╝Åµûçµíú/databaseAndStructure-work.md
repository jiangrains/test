## 作品系统

业务代码：103

### work

业务代码：103101

#### work表

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|title|varchar(255)|作品标题  1-25
|cover|text|作品封面 1-1024
|summary|text|作品简介 1-500
|pic_desc|text|作品图片描述：格式 [{path:"",desc:""},{path:"",desc:""}...] 1-30000
|user_id|init(32)|用户id
|category_id|int(32)|分类id
|last_save_date|datetime|最后保存时间
|publish_date|datetime|发布时间
|status|tinyint|状态，0：草稿，1：发布，2：删除
|display_count|int(32)|浏览数
|praise_count|int(32)|点赞数
|followed_count|int(32)|被关注数
|patents|text|专利,json 格式:[{name:"xxx",code:"xxx"},{name:"xxx",code:"xxx"}……] 0-10000
|custom_tags|text|自定义标签 0-512
|visiable|tinyint(2)|可见LEVEL：0:私有;1:公开

##### enum字段设计

    status, DRAFT:草稿; PUBLISHED: 发布; REMOVED 删除;
    visiable, PRIVATE:私有；PUBLIC:公开；

#### work_tag表

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|text|varchar(255)|标签名称

#### work_rel_tag表

|字段名|类型|备注
|---|---|---
|work_id|int(32)|作品id
|tag_id|int(32)|标签id

#### /work/browse

作品详情

|字段名|描述
|---|---
|token|令牌
|workId|作品id（不可与其它字段并存）

    {
        id: [Number]
        title: [String],
        cover: [String],
        summary: [String],
        picDesc: [String],
        user: [User Object],
        category: [Category],
        displayCount: [Number],
        praiseCount: [Number],
        followedCount: [Number],
        customTags: [String],
        status: [Number]
        sysTags: [{
            id: [Number],
            text: [String],
            primary: [Boolean]
        },...],
        patentCode: [String],
        patentName: [String],
        lastSaveDate: [Number],
        publishDate: [Number]
    }

#### /work/search

搜索作品

|字段名|描述
|---|---
|search_eq_user.id|用户id（可不提供）
|search_like_title|搜索关键词（一级）
|search_eq_category.id|分类id（二级）
|search_eq_sysTags.id|标签（三级)

##### 分页按 issuse #16  排序方式，默认为时间从晚到早

    {
        list: [[Work Object],...],
        currentPage: [Number],
        totalPages: [Number]
    }

#### /work/save

保存作品

|字段名|描述
|---|---
|token|令牌
|id|作品id（没有id就是新建一个作品）
|title|作品标题
|cover|作品封面
|summary|作品简介
|picDesc|作品图片描述
|categoryId|分类id
|patentCode|专利号
|patentName|专利名称
|customTags|自定义标签
|visiable| 作品是显示LEVEL:PRIVATE,PUBLIC；


    {
        workId: [Number]
        lastSaveDate: [Number]
    }

#### /work/publish

发布作品

|字段名|描述
|---|---
|token|令牌
|id|作品id（没有id就是新建一个作品）
|title|作品标题
|cover|作品封面
|summary|作品简介
|picDesc|作品图片描述
|categoryId|分类id
|patentCode|专利号
|patentName|专利名称
|customTags|自定义标签
|visiable| 作品是显示LEVEL:PRIVATE,PUBLIC；


    {
        workId: [Number]
        publishDate: [Number]
    }


#### /work/remove

发布作品

|字段名|描述
|---|---
|token|令牌
|workId|作品id

    {}


### work_category

业务代码：103102

#### work_category表

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|name|varchar(255)|分类名称
|parent_id|int(32)|父分类id

#### /work/category/list

分类列表

|字段名|描述
|---|---
|parentId|父分类id，可选。

    {
        list: [{
            id: [Number]
            name: [String]
            childList: [{
                id: [Number],
                name: [String]
            },...]
        },...]
    }

