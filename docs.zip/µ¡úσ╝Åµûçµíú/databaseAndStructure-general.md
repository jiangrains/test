## 通用系统

业务码：100

### 随机码

业务码：100101

#### /sys/captcha.gif

生成随机码图片

|字段名|描述
|---|---
|type|验证码类型，1：纯数字，2：纯字母，3：混合，4：复杂

#### /sys/captcha

校验随机码

|字段名|描述
|---|---
|captcha|随机校验码


    {
        isCorrect: [Boolean]
    }

#### /sys/active/code

校验随机码

|字段名|描述
|---|---
|username|email/phone


    {}
    

#### feedback表

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|title| varchar(64)|反馈标题 1-25
|content|text|反馈内容 10-10000
|create_time|datetime|反馈时间
|ip|varchar(24)|反馈IP
|user_agent|text|反馈的用户代理
|user|text|反馈人：json字符串

#### /sys/feedback

信息反馈

|字段名|描述
|---|---
|title|反馈标题
|content|反馈内容


    {}


