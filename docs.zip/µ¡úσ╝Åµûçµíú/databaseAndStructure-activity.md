## 活动系统

业务代码：104

### activity

业务代码：104101

#### activity表

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|title|varchar(128)|活动标题 1-25
|cover|text|活动封面 1-1024
|display_count|int(32)|浏览数
|praise_count|int(32)|点赞数
|followed_count|int(32)|被关注数
|information_tpl_id|int(32)|活动信息模板id
|information|text|活动信息 1-30000
|submit_tpl_id|int(32)|提交作品信息模板id
|status|tinyint|0：未发布，1：已发布，2：已结束
|last_save_date|datetime|最后保存时间
|publish_date|datetime|发布时间
|user_id|int(32)|用户id
|enroll_start_date|datetime|报名开始时间 yyyy-MM-dd HH:mm
|judge_start_date|datetime|评审开始时间 yyyy-MM-dd HH:mm
|download_uri|varchar(255)|作品下载地址

##### enum字段设计

    status, UNPUBLISHED:未发布; PUBLISHED: 发布; ENDED 已结束;

#### activity_information_template表

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|name|varchar(128)|模板名称
|fields|text|模板字段列表，格式：[{name: [String], type: [String], desciption: [String]}, ...]
|render_uri|text|模板效果图URI

#### activity_submit_template表

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|name|varchar(128)|模板名称
|fields|text|模板字段列表，格式：[{name: [String], type: [String], desciption: [String]}, ...]
|render_uri|text|模板效果图URI

#### activity_tag表

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|text|varchar(255)|标签名称

#### activity_rel_tag表

|字段名|类型|备注
|---|---|---
|activity_id|int(32)|活动id
|tag_id|int(32)|标签id

#### /activity/detail

活动详情

|字段名|描述
|---|---
|activityId|活动id

    {
        id: [Number]
        title:[String],
        cover:[String],
        displayCount: [Number],
        praiseCount: [Number],
        followedCount: [Number],
        informationTplId: [Number],
        information: [String],
        enrollStartDate: [Long],
        judgeStartDate: [Long],
        submitTplId: [Number]
        user: [User Object],
        status: [Number],
        sysTags: [{
            id: [Number],
            text: [String],
            primary: [Boolean]
        },...],
        lastSaveDate: [Long],
        publishDate: [Long]
    }


#### /activity/search

搜索活动

|字段名|描述
|---|---
|search_eq_user.id|用户id（可不提供）
|search_eq_sysTags.id| tag id

##### 分页按 issuse #16  排序方式，默认为时间从晚到早

    {
        list: [[Activity Object],...],
        totalPages: [Number]
    }

#### /activity/save

保存活动

|字段名|描述
|---|---
|token|令牌
|id|活动id（没有id就是新建一个活动）
|title|活动标题
|cover|活动封面
|informationTplId|活动信息模板id
|information|活动信息
|enrollStartDate|作品提交起始时间  yyyy-MM-dd HH:mm
|judgeStartDate|作品提交截止时间  yyyy-MM-dd HH:mm
|submitTplId|提交作品信息模板id


    {
        activityId: [Number]
        lastSaveDate: [Long]
    }

#### /activity/publish

发布活动

|字段名|描述
|---|---
|token|令牌
|id|活动id（没有id就是新建一个活动）
|title|活动标题
|cover|活动封面
|informationTplId|活动信息模板id
|information|活动信息
|enrollStartDate|作品提交起始时间  yyyy-MM-dd HH:mm
|judgeStartDate|作品提交截止时间  yyyy-MM-dd HH:mm
|submitTplId|提交作品信息模板id


    {
        activityId: [Number]
        publishDate: [Long]
    }

#### /activity/template/info

信息模板查询

|字段名|描述
|---|---
|templateId|模板ID

    {
        informationTpl
    }

#### /activity/template/info/list

信息模板列表

    {
        list:[informationTpl]
    }

#### /activity/template/submit

提交模板查询

|字段名|描述
|---|---
|templateId|模板ID

    {
        submitTpl
    }

#### /activity/template/submit/list

提交模板列表

    {
        list:[submitTpl]
    }


### activity_work

业务代码：104102

#### activity_rel_work表

|字段名|类型|备注
|---|---|---
|id|int(32)|自增
|activity_id|int(32)|活动id
|submit_tpl_id|int(32)|提交作品信息模板id
|submit_text|text|提交作品信息
|submit_date|datetime|提交时间
|work_id|int(32)|作品id
|list_snapshoot|text|作品列表快照
|work_snapshoot|text|作品快照（作品的json）
|user_id|int(32)|用户id
|status|tinyint|0：未提交，1：已报名，2：退回
|remark|text|退回作品的备注

##### enum字段设计

    status, DRAFT:未提交; ENROLLED: 已报名; REJECTED：退回;

#### /activity/work/submit

作品报名

|字段名|描述
|---|---
|token|令牌
|id|报名ID（没有id就是新建一个活动）
|activityId|活动id
|submitTplId|活动信息模板id
|submitText|活动信息
|workId|作品id

    {
        submitDate: [Long]
    }
    
#### /activity/work/reject

作品回退

|字段名|描述
|---|---
|token|令牌
|enrollId|参赛id
|remark|回退理由

    {}

#### /activity/work/search

搜索作品

|字段名|描述
|---|---
|activityId|活动id(必填)
|search_like_work.title|搜索关键词
|search_like_work.customTags|标签

##### 分页按 issuse #16  排序方式，默认为时间从晚到早

    {
        list: [[ActivityRelWork Object],...],
        currentPage: [Number],
        totalPages: [Number]
    }

#### /activity/work/browse

浏览参赛作品

|字段名|描述
|---|---
|token|令牌
|enrollId|参赛id(必填)

##### 分页按 issuse #16  排序方式，默认为时间从晚到早

    {
        ActivityRelWork
    }



