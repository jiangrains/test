## 消息系统

业务码：105

### notice

业务码：105101

#### notice 表

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|title| varchar(64)| 通知标题 1-25
|content| text | 通知内容 10-400
|create_by|int(32)| 创建人
|create_time|datetime|创建时间
|modify_by|int(32)| 创建人
|modify_time|datetime|创建时间

### news

业务码：105102

#### news 表

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|title| varchar(64)| 通知标题 1-25
|bref| varchar(255)| 简介 5-100
|cover_uri| text| 封面 0-1024
|source | varchar(100)| 来源 1-50
|publish_time| datetime | 发布时间
|content| text | 通知内容 10-10000
|create_by|int(32)| 创建人
|create_time|datetime|创建时间
|modify_by|int(32)| 创建人
|modify_time|datetime|创建时间