## 用户系统

业务码：102

### user

业务码：102101

#### user表

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|nick|varchar(255)|昵称 1-20
|avatar|text|头像地址 0-1024


#### designer表（user表的子表）

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|user_id|int(32)|用户id
|profile|text|个人简介 0-200
|skills|text|技能 0-100

#### organization（user表的子表）

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|user_id|int(32)|用户id
|name|varchar(100)| 全称 0-50
|code|varchar(50)|组织机构代码 0-20
|photo|text|证件照 0-1024
|description|text|机构描述 0-200
|owner|varchar(50)|机构法人 0-25
|industry|varchar(50)|所属行业 0-25

#### /user

获取用户信息

|字段名|描述
|---|---
|token|令牌

    {
        accountType:  [String],
        user: [User]
    }

#### /user/profile

获取用户资料

|字段名|描述
|---|---
|token|令牌

    {
        account: {
            email: [String],
            phone: [String],
            qqId: [String],
            weixinId: [String],
            weiboId: [String],
            alipayId: [String],
            type: [String]
        },
        profile: {
            nick: [String],
            avatar: [String],
            ...
        },
        attendList: [
            {type:0, count:3},
            {type:1, count:4},...,
            {type:3, count:5}
        ]
    }

    attend.type, 0: 作品总浏览量；1：收获点赞数；2：我关注的人；3：关注我的人；

#### /user/profile/edit/{accountType}

修改用户资料

|字段名|描述
|---|---
|token|令牌
|nick|昵称
|avatar|头像
|设计师部分|---
|profile|个人简介
|skills|技能
|主办方部分|---
|name|机构全称
|code|组织机构代码
|photo|证件照
|description|机构描述
|owner|机构法人
|industry|所属行业

    {}

#### /user/profile/uploadavatar

上传用户头像

|字段名|描述
|---|---
|token|令牌
|image|图片数据对象


    redirect:http://www.izuoba.com/user/upload?success=[Boolean]&cdnurl=[String]&errorCode=[String]

#### /user/works

用户作品集

|字段名|描述
|---|---
|token|令牌
|search_like_title| 标题检索

##### 分页按 issuse #16  排序方式，默认为时间从晚到早

    {
        list: [{Work},...],
        currentPage: [Number],
        totalPages: [Number]
    }

#### /user/works/draft

用户作品草稿集

|字段名|描述
|---|---
|token|令牌
|search_like_title| 标题检索

##### 分页按 issuse #16  排序方式，默认为时间从晚到早

    {
        list: [{Work},...],
        currentPage: [Number],
        totalPages: [Number]
    }
    
#### /user/works/enroll

用户参赛作品集

|字段名|描述
|---|---
|token|令牌
|search_like_work.title| 标题检索

##### 分页按 issuse #16  排序方式，默认为时间从晚到早

    {
        list: [{ActivityRelWork},...],
        currentPage: [Number],
        totalPages: [Number]
    }

#### /user/activities

用户活动集

|字段名|描述
|---|---
|token|令牌
|search_like_title| 标题检索

##### 分页按 issuse #16  排序方式，默认为时间从晚到早

    {
        list: [{activity},...],
        currentPage: [Number],
        totalPages: [Number]
    }

#### /user/activities/draft

用户活动草稿集

|字段名|描述
|---|---
|token|令牌
|search_like_title| 标题检索

##### 分页按 issuse #16  排序方式，默认为时间从晚到早

    {
        list: [{activity},...],
        currentPage: [Number],
        totalPages: [Number]
    }

### user_follow_work

业务码：102102

#### user_follow_work表

|字段名|类型|备注
|---|---|---
|user_id|int(32)|用户id
|followed_work_id|int(32)|作品id
|followed_date|Datetime|关注时间
|status|tinyint(2)|状态，0：取消关注，1：已关注

##### enum字段设计

    status, UNFOLLOW:取消关注; FOLLOW: 已关注;

#### /user/following/works

列出所有关注的作品

|字段名|描述
|---|---
|token|令牌
|search_like_work.title| 作品标题搜索

##### 分页按 issuse #16  排序方式，默认为时间从晚到早

    {
        list: [{
            obj: [Work Object],
            followedDate: [Long],
            status: [Number]
        }],
        currentPage: [Number],
        totalPages: [Number]
    }


#### /user/follow/work

关注某个作品

|字段名|描述
|---|---
|token|令牌
|workId|作品id

    {
        isAlreadyFollowing: [Boolean],
        followedDate: [Long]
    }

#### /user/unfollow/work

取消关注某个作品

|字段名|描述
|---|---
|token|令牌
|workId|作品id

    {
        isAlreadyUnfollowed: [Boolean]
    }
    
#### /user/isfollow/work

是否关注某个作品

|字段名|描述
|---|---
|token|令牌
|workId|作品id

    {
        isFollowed: [Boolean]
    }

### user_follow_activity

业务码：102103

#### user_follow_activity表

|字段名|类型|备注
|---|---|---
|user_id|int(32)|用户id
|followed_activity_id|int(32)|活动id
|followed_date|Datetime|关注时间
|status|tinyint(2)|状态，0：取消关注，1：已关注

##### enum字段设计

    status, UNFOLLOW:取消关注; FOLLOW: 已关注;

#### /user/following/activities

列出所有关注的活动

|字段名|描述
|---|---
|token|令牌
|search_like_activity.title| 活动标题搜索

##### 分页按 issuse #16  排序方式，默认为时间从晚到早

    {
        list:[{
            obj: [Activity Object],
            followedDate: [Long],
            status: [Number]
        }],
        currentPage: [Number],
        totalPages: [Number]
    }


#### /user/follow/activity

关注某个作品

|字段名|描述
|---|---
|token|令牌
|activityId|活动id

    {
        isAlreadyFollowing: [Boolean],
        followedDate: [Long]
    }

#### /user/unfollow/activity

取消关注某个作品

|字段名|描述
|---|---
|token|令牌
|activityId|活动id

    {
        isAlreadyUnfollowed: [Boolean]
    }
    
#### /user/isfollow/activity

是否关注某个作品

|字段名|描述
|---|---
|token|令牌
|activityId|活动id

    {
        isFollowed: [Boolean]
    }

### user_follow_user

业务码：102104

#### user_follow_user表

|字段名|类型|备注
|---|---|---
|user_id|int(32)|用户id
|followed_user_id|int(32)|被关注的用户id
|followed_date|Datetime|关注时间
|status|tinyint(2)|状态，0：取消关注，1：已关注

##### enum字段设计

    status, UNFOLLOWED:取消关注; FOLLOWED: 已关注;

#### /user/following/users

列出所有我关注的用户

|字段名|描述
|---|---
|token|令牌
|search_like_followedUser.nick| 作品标题搜索

##### 分页按 issuse #16  排序方式，默认为时间从晚到早

    {
        list:[{
            followedUser: [User Object],
            followedDate: [String],
            status: [Number]
        }],
        currentPage: [Number],
        totalPages: [Number]
    }

#### /user/followed/users

列出关注我的用户

|字段名|描述
|---|---
|token|令牌
|search_like_user.nick| 作品标题搜索

##### 分页按 issuse #16  排序方式，默认为时间从晚到早

    {
        list:[{
            followedUser: [User Object],
            followedDate: [String],
            status: [Number]
        }],
        currentPage: [Number],
        totalPages: [Number]
    }


#### /user/follow/user

关注某个用户

|字段名|描述
|---|---
|token|令牌
|userId|用户id

    {
        isAlreadyFollowing: [Boolean]
        followedDate: [String]
    }

#### /user/unfollow/user

取消关注某个用户

|字段名|描述
|---|---
|token|令牌
|userId|用户id

    {
        isAlreadyUnfollowed: [Boolean]
    }

#### /user/isfollow/user

是否关注某个用户

|字段名|描述
|---|---
|token|令牌
|userId|用户id

    {
        isFollowed: [Boolean]
    }
    

### user_star_work

业务码：102105

#### user_star_work表

|字段名|类型|备注
|---|---|---
|user_id|int(32)|用户id
|work_id|int(32)|作品id
|star_time|Datetime|关注时间


#### /user/star/work

点赞某个作品

|字段名|描述
|---|---
|token|令牌
|workId|作品id

    {}
    
#### /user/isstar/work

是否点赞某个作品

|字段名|描述
|---|---
|token|令牌
|workId|作品id

    {
        isStared: [Boolean]
    }

### user_star_activity

业务码：102105

#### user_star_activity表

|字段名|类型|备注
|---|---|---
|user_id|int(32)|用户id
|activity_id|int(32)|活动id
|star_time|Datetime|点赞时间

#### /user/star/activity

关注某个活动

|字段名|描述
|---|---
|token|令牌
|activityId|活动id

    {}
    
#### /user/isstar/activity

是否点赞某个活动

|字段名|描述
|---|---
|token|令牌
|activityId|活动id

    {
        isStared: [Boolean]
    }

