## 账户系统

业务码：101

### account

业务码：101101

#### account表

|字段名|类型|备注
|---|---|---
|id|int(32)|自增长
|token|char(32)|令牌（uuid）
|token_expire_date|datetime|令牌过期时间
|email|varchar(255)|邮箱
|phone|char(11)|手机
|username|varchar(100)|用户名
|password|char(32)|密码（md5_32）
|salt| varchar(32)|密码盐
|signup_date|datetime|注册时间
|signup_type|tinyint(2)|注册类型,0：email, 1: phone, 2: qq, 3: weixin, 4: weibo, 5:alipay
|signin_date|datetime|最后登录时间
|validate_code|char(6)|验证码
|validate_code_expire_date|datetime|验证码过期时间
|status|tinyint(2)|0: 未激活，1：正常，2：锁定
|qq_id|varchar(255)|绑定qq的id
|weixin_id|varchar(255)|绑定微信的id
|weibo_id|varchar(255)|绑定微博的id
|alipay_id|varchar(255)|绑定支付宝的id
|qq_access_token|varchar(255)|qq的access_token
|weixin_access_token|varchar(255)|微信的access_token
|weibo_access_token|varchar(255)|微博的access_token
|alipay_access_token|varchar(255)|支付宝的access_token
|user_id|int(32)|用户id，FK
|type|tinyint(2)|类型，1：普通用户，2：设计师，3：主办方


##### enum字段设计

    signup_type, EMAIL:email; PHONE:phone; WEIXIN:weixin; WEIBO:weibo; ALIPAY:alipay;
    status, NOTACTIVATED:未激活; NORMAL: 正常; LOCKED:锁定;
    type,  NORMAL:普通用户; DESIGNER:设计师; ORGANIZER：主办方;


#### /account/signup

注册账户

|字段名|描述
|---|---
|username|账户名（邮箱/手机）
|plainPassword| 密码
|captcha|随机校验码


    {
        signupDate: [Long]
    }



#### /login

用账户名登录

|字段名|描述
|---|---
|username|账户名
|password|账户密码
|captcha|随机校验码

    {
        signinDate: [Long]
    }

用令牌自动登录

|字段名|描述
|---|---
|token|令牌

    {
        signinDate: [Long]
    }

#### /logout

注销账户

|字段名|描述
|---|---
|token|令牌

    {}


#### /account/link

链接第三方认证

|字段名|描述
|---|---
|site|认证来源
|id|第三方的id
|token|第三方令牌

    {
        signupDate: [Long],
        siginDate: [Long],
        isNewUser: [Boolean]
    }

#### /account/active

编辑账户信息

|字段名|描述
|---|---
|username| email/phone
|activeCode|验证码

    {
        success:[Boolean]
    }

#### /account/become/{type}

修改账户类型

|字段名|描述
|---|---
|token|令牌

    {}

#### /account/has

检查是否存在账户

|字段名|描述
|---|---
|username|账户名

    {
        has: [Boolean]
    }

#### /account/changePassword

修改密码接口

|字段名|描述
|---|---
|token| 令牌
|oriPassword| 原密码
|newPassword| 新密码

    {}

#### /account/resetPassword

修改密码接口

|字段名|描述
|---|---
|username| 用户名
|activeCode| 激活码
|newPassword| 新密码

    {
        success:[BOOLEAN]
    }

